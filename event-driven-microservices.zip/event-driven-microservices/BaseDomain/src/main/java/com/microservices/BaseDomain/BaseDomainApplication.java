package com.microservices.BaseDomain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaseDomainApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaseDomainApplication.class, args);
	}

}
