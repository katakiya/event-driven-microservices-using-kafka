package com.microservices.EmailService.Kafka;

import com.microservices.BaseDomain.dto.OrderEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class OrderConsumer {

    @KafkaListener(topics = "${spring.kafka.topic.name}" , groupId = "${spring.kafka.consumer.group-id}")
    public void consume(OrderEvent orderEvent){
        // implement the real logic whatever you want to do when you receive an order event.
        System.out.println("..... Order Event Received with details :::: "+orderEvent.toString());
    }
}
