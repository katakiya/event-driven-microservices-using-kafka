package com.microservices.OrderService.kafka;

import com.microservices.BaseDomain.dto.OrderEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

@Service
public class OrderProducer {

    @Autowired
    KafkaTemplate kafkaTemplate;

    @Value("${spring.kafka.topic.name}")
    private String topicName;

    public void sendOrderMessage(OrderEvent orderEvent){
        Message<OrderEvent> message = MessageBuilder
                .withPayload(orderEvent)
                .setHeader(KafkaHeaders.TOPIC , this.topicName)
                .build();
        kafkaTemplate.send(message);
    }
}
